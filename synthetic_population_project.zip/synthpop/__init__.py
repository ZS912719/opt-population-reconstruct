"""Exact marginal synthetic populations."""
